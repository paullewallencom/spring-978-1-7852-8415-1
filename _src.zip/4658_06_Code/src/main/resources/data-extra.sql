INSERT INTO author (id, first_name, last_name) VALUES (6, 'John', 'Doe')
INSERT INTO publisher (id, name) VALUES (3, 'Fictitious Books')
INSERT INTO book (isbn, title, author_id, publisher_id) VALUES ('978-1-23456-789-0', 'Phantom Writing', 6, 3)