INSERT INTO author (id, first_name, last_name) VALUES (3, 'William', 'Shakespeare')
INSERT INTO publisher (id, name) VALUES (2, 'Classical Books')
INSERT INTO book (isbn, title, author_id, publisher_id) VALUES ('978-1-23456-789-1', 'Romeo and Juliet', 3, 2)