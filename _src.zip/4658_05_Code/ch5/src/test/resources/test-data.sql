INSERT INTO author (id, first_name, last_name) VALUES (2, 'Greg', 'Turnquist')
INSERT INTO book (isbn, title, author_id, publisher_id) VALUES ('978-1-78439-302-1', 'Learning Spring Boot', 2, 1)